#pragma once
#pragma warning(disable : 4244)
// conversion from 'int' to 'short', possible loss of data
#pragma warning(disable : 4018)
// signed/unsigned mismatch
#pragma warning(disable : 4996)
// 'sscanf': This function or variable may be unsafe
#pragma warning(disable : 4334)
// '<<' : result of 32-bit shift implicitly converted to 64 bits
#pragma warning(disable : 4098)
// 'void' function returning a value
#pragma warning(disable : 4761)
// integral size mismatch in argument; conversion supplied
#pragma warning(disable : 4311)
// pointer truncation from 'void *' to 'DWORD'
#pragma warning(disable : 4090)
// different 'const' qualifiers
#pragma warning(disable : 4101)
// unreferenced local variable
