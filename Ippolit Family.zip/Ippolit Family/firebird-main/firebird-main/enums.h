#pragma once
typedef enum
{
	wEnumOcc, wEnumP, wEnumN, wEnumK, wEnumBL, wEnumBD, wEnumR, wEnumQ,
	bEnumOcc, bEnumP, bEnumN, bEnumK, bEnumBL, bEnumBD, bEnumR, bEnumQ
} EnumPieces;

typedef enum
{
	A1, B1, C1, D1, E1, F1, G1, H1,
	A2, B2, C2, D2, E2, F2, G2, H2,
	A3, B3, C3, D3, E3, F3, G3, H3,
	A4, B4, C4, D4, E4, F4, G4, H4,
	A5, B5, C5, D5, E5, F5, G5, H5,
	A6, B6, C6, D6, E6, F6, G6, H6,
	A7, B7, C7, D7, E7, F7, G7, H7,
	A8, B8, C8, D8, E8, F8, G8, H8
} EnumSquares;

typedef enum
{
	R1, R2, R3, R4, R5, R6, R7, R8
} EnumRanks;

typedef enum
{
	FA, FB, FC, FD, FE, FF, FG, FH 
} EnumFiles;

typedef enum
{
	Trans,
	CaptureGen,
	Capture_Moves,
	Killer1,
	Killer2,
	Ordinary_Moves,
	BadCaps,
	Trans2,
	CaptureGen2,
	CaptureMoves2,
	QuietChecks,
	Evade_Phase,
	Trans3,
	CaptureGen3,
	CaptureMoves3,
	QuietChecks3,
	PositionalGainPhase,
	Fase0
} EnumPhases;

typedef enum
{
	ooK = 1,
	ooQ = 2,
	ook = 4,
	ooq = 8
} CastlingTable;

typedef enum
{
	KQkq = ooK | ooQ | ook | ooq,
	Qkq = ooQ | ook | ooq,
	Kkq = ooK | ook | ooq,
	kq = ook | ooq,
	KQk = ooK | ooQ | ook,
	KQ = ooK | ooQ,
	KQq = ooK | ooQ | ooq
} KQkqTable;
