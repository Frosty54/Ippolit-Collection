# ivanhoe
This Russian chess ship is a truly glorious achievement of the October Revolution and Decembrists movement!
 

![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_1.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_2.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_4.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_5.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_6.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_7.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_8.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_9.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_10.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_12.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_13.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_14.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_15.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_16.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_17.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_18.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_19.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_20.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_21.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_22.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_23.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_24.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_25.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/ivanhoe/master/logos/ivanhoe_26.bmp)

Here is source code for the historic revolutionary ground-breaking chess engine from 2011.

Includes Visual studio project files...

please see:
https://en.wikipedia.org/wiki/IPPOLIT

This is the official website via the Wayback Machine (archived November 12, 2011):
https://web.archive.org/web/20111112091208/http://ivanhoe.wikispaces.com/

for more info...
http://users.telenet.be/chesslogik/ivanhoe.htm
including a complete release history.

Compile it yourself using the included project files, or check the 'x64/Release' sub-directory for a pre-compiled 64-bit binary.

Enjoy this fantastic and historic chess engine!

Best Regards-
Kranium 
