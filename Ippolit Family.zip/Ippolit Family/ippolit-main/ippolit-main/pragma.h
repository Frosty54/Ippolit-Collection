
#pragma warning (disable : 4554)
#pragma warning (disable : 4805)
#pragma warning (disable : 4244)
#pragma warning (disable : 4996)
#pragma warning (disable : 4101)
#pragma warning (disable : 4102)
#pragma warning (disable : 4334)
#pragma warning (disable : 4018)