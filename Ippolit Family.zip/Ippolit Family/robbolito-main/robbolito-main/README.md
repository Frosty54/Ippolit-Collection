# robbolito
Robbolito 0.85g3 original 2009 source code..developed from the famous ground breaking Ippolit release

![alt tag](https://raw.githubusercontent.com/FireFather/robbolito/master/robbolito.png)
![alt tag](https://raw.githubusercontent.com/FireFather/robbolito/master/robbolite.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/robbolito/master/robbolito.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/robbolito/master/robbolito_2.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/robbolito/master/robbolito_3.bmp)

![alt tag](https://raw.githubusercontent.com/FireFather/robbolito/master/robbolito084.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/robbolito/master/robbolito085c3.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/robbolito/master/robbolito085d1.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/robbolito/master/robbolito085d2.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/robbolito/master/robbolito085d3.bmp)

![alt tag](https://raw.githubusercontent.com/FireFather/robbolito/master/robbolito085d4.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/robbolito/master/robbolito085d5.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/robbolito/master/robbolito085d6.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/robbolito/master/robbolito085d7.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/robbolito/master/robbolito085f1.bmp)

for more info:
http://users.telenet.be/chesslogik/robbolito.htm

also please see:
https://en.wikipedia.org/wiki/IPPOLIT

Here is the official website via the Wayback Machine (archived November 12, 2011):

https://web.archive.org/web/20111112091208/http://ippolit.wikispaces.com/

There's a lot to read about this revolutionary project.


