# igorrit
version 9 of the famous Ippolit chess engine

![alt tag](https://raw.githubusercontent.com/FireFather/igorrit/master/igorrit.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/igorrit/master/igorrit_1.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/igorrit/master/igorrit_2.bmp)

![alt tag](https://raw.githubusercontent.com/FireFather/igorrit/master/igorrit_3.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/igorrit/master/igorrit_4.bmp)
![alt tag](https://raw.githubusercontent.com/FireFather/igorrit/master/igorrit_5.bmp)

for more info: http://users.telenet.be/chesslogik/robbolito.htm

also please see: https://en.wikipedia.org/wiki/IPPOLIT

Here is the official website via the Wayback Machine (archived November 12, 2011):

https://web.archive.org/web/20111112091208/http://ippolit.wikispaces.com/
